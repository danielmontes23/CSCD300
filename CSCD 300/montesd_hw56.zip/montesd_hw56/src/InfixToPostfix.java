import java.util.*;

public class InfixToPostfix {

    public static Stack stackInfix = new Stack();

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        String d;

        Scanner kb = new Scanner(System.in);
        System.out.println("Enter an Infix expression: ");
        d = kb.nextLine();
        String x = InfixToPostfix(d);
        int z = evaluate(x);

        System.out.println("The postfix expression is: " + x);
        System.out.println("The final result of the postfix is: " + z);
    }

    /**
     *
     * @param s
     * @return
     */
    private static String InfixToPostfix(String s) {
        char cur;
        String output = "";
        for (int i = 0; i < s.length(); ++i) {
            cur = s.charAt(i);
            if (Character.isDigit(cur)) {
                output = output + cur;
            } else if (cur == '(') {
                stackInfix.push(cur);
            } else if (cur == ')') {
                while (!stackInfix.isEmpty() && (char) stackInfix.top() != '(') {
                    output = output + stackInfix.pop();
                }
                stackInfix.pop();
            } else {
                while (!stackInfix.isEmpty() && (precedence(cur) <= precedence((char) stackInfix.top()))) {
                    output = output + stackInfix.pop();
                }
                stackInfix.push(cur);
            }
        }
        while (!stackInfix.isEmpty()) {
            output = output + stackInfix.pop();
        }
        return output;
    }

    /**
     *
     * @param a
     * @return
     */
    public static int precedence(char a) {
        if (a == '+' || a == '-') {
            return 2;
        }
        if (a == '*' || a == '/' || a == '^') {
            return 3;
        }
        return 0;
    }

    public static int evaluate(String postFix) {
        Stack stack = new Stack();

        for (int i = 0; i < postFix.length(); i++) {
            char c = postFix.charAt(i);

            if (Character.isDigit(c))
                stack.push(Character.getNumericValue(c));
            else {
                int right = (int)stack.pop();
                int left = (int)stack.pop();
                int res = 0;
                if (c == '+') {
                    res = left + right;
                }
                if (c == '-') {
                    res = left - right;
                }
                if (c == '*') {
                    res = left * right;
                }
                if (c == '/') {
                    res = left / right;
                }
                stack.push(res);
            }
        }
        return (int)stack.pop();
    }
}